package com.example.guru2


import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator
import org.w3c.dom.Text

class MainActivity : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val imagebutton=findViewById<ImageButton>(R.id.button)
        imagebutton.setOnClickListener {

            val intent = Intent(this, Main_BookMark::class.java)
            startActivity(intent)


        }

        val button = findViewById<Button>(R.id.button1)//당일치기

        button.setOnClickListener {

            val intent = Intent(this, Travel_today::class.java)
            startActivity(intent)


        }
        val button2 = findViewById<Button>(R.id.button2)//1-2일여행
        button2.setOnClickListener {
            val intent = Intent(this, Travel_second::class.java)
            startActivity(intent)
        }

        //장기여행
        val button3 = findViewById<Button>(R.id.button3)
        button3.setOnClickListener {
            val intent = Intent(this, Travel_long::class.java)
            startActivity(intent)
        }
        //액티비티
        val button4 = findViewById<Button>(R.id.button4)
        button4.setOnClickListener {
            val intent = Intent(this, Travel_Activity::class.java)
            startActivity(intent)
        }

        val button5 = findViewById<Button>(R.id.button5)
        button5.setOnClickListener {
            val intent = Intent(this, Travel_Healing::class.java)
            startActivity(intent)
        }

        val button6 = findViewById<Button>(R.id.button6)
        button6.setOnClickListener {
            val intent = Intent(this, Travel_Exhibition::class.java)
            startActivity(intent)
        }
        val viewPager2Adapter = ViewPager2Adapter(supportFragmentManager, lifecycle)
        val viewPager2 = findViewById<ViewPager2>(R.id.viewPager)
        viewPager2.adapter = viewPager2Adapter

        //=== TabLayout기능 추가 부분//오른쪽으로 스와이프 할 수 있는 기능//에뮬레이터에서 작동x 확인 필요 ============================================
        val tabLayout = findViewById<TabLayout>(R.id.tabLayout)
        TabLayoutMediator(tabLayout, viewPager2) { tab, position ->
            tab.text = "Tab ${position + 1}"
        }.attach()

        viewPager2.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                super.onPageSelected(position)
                tabLayout.selectTab(tabLayout.getTabAt(position))
            }
        })


        // BottomNavigationView 초기화
        val bottomNavigationView = findViewById<BottomNavigationView>(R.id.bottom_navigation_menu)

        // BottomNavigationView 아이템 클릭 리스너 등록
        bottomNavigationView.setOnNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.navigation_feed-> {
                    val intent = Intent(this, FeedActivity::class.java)
                    startActivity(intent)
                    true
                }
                R.id.navigation_home -> {
                    // 홈 화면으로 이동
                    val intent = Intent(this, MainActivity::class.java)
                    startActivity(intent)
                    true
                }
                R.id.navigation_my-> {
                    // 마이페이지로 이동
                    val intent = Intent(this, MyPage::class.java)
                    startActivity(intent)
                    true
                }
                else -> false
            }
        }
    }
}

