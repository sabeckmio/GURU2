package com.example.guru2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import com.google.android.material.bottomnavigation.BottomNavigationView

class MyPage : AppCompatActivity() {

    //lateinit var nickname: EditText
    lateinit var myFeedButton: Button
    lateinit var bookMarkButton: Button
    //lateinit var backButton: ImageButton
    lateinit var editButton: ImageButton
    lateinit var myPhotoButton: Button

    lateinit var bottomNavigationView: BottomNavigationView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.my_page)

        myPhotoButton = findViewById<Button>(R.id.myPhotoButton)
        myFeedButton = findViewById<Button>(R.id.myFeedButton)
        bookMarkButton = findViewById<Button>(R.id.bookMarkButton)


        myPhotoButton.setOnClickListener {
            var intent = Intent(this, MyPhoto::class.java)
            startActivity(intent)
        }

        myFeedButton.setOnClickListener {
            var intent = Intent(this, MyFeed::class.java)
            startActivity(intent)
        }
        bookMarkButton.setOnClickListener{
            var intent = Intent( this, BookMark::class.java)
            startActivity(intent)
        }

        //하단 네이게이션 바
        bottomNavigationView = findViewById(R.id.bottomNavigationView)
        bottomNavigationView.setOnNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.navi_home -> {
                    val intent = Intent(this, MainActivity::class.java)
                    startActivity(intent)
                    true
                }
                R.id.navi_feed -> {
                    val intent = Intent(this, FeedActivity::class.java)
                    startActivity(intent)
                    true
                }
                R.id.navi_mypage -> {
                    val intent = Intent(this, MyPage::class.java)
                    startActivity(intent)
                    true
                }
                else -> false
            }
        }

    }

}