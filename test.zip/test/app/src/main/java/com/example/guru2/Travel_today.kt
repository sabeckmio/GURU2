package com.example.guru2

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class Travel_today: AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.travel_today)
    }
}
